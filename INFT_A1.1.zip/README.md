# INFT_A1.1

## Commit History

### Background colors set

1. Set background color
2. Set footer and header background colors

### Set initial font colors

1. Set the text color in main, footer and header
2. Set links color on start_page
3. Set link hover over color
4. Fix minor syntax errors in body

### Aligned and restyled header

1. Aligned header to center
2. Set size to 150%
3. Set font color to c-yellow.

### Navigatiion & Related design, page width, headings

1. Navigation: removed bullet points from navigation, allignd navigation to centre and applied fle layout
2. Related: section links color to c-red and c-blue when hovered over
3. Set max page width to 800px, note: has not been centered as not requested.
4. All headings: set top padding to 50px.
5. Corrections: corrected error in header background color, Related section font color